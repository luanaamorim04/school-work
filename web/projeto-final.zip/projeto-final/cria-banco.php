<?php
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $db = 'dados';

    $conn = mysqli_connect($servername, $username, $password);

    $consulta = "CREATE DATABASE dados;";
    $result = mysqli_query($conn, $consulta);
    mysqli_select_db($conn, $db);

    $consulta = "CREATE TABLE Aluno (
              matricula INT PRIMARY KEY,
              nome VARCHAR(255) NOT NULL,
              login VARCHAR(255) NOT NULL,
              email VARCHAR(255),
              senha VARCHAR(255) NOT NULL
              );";

    $result = mysqli_query($conn, $consulta);

    $consulta = "CREATE TABLE Materia (
              matricula INT,
              nome VARCHAR(255) NOT NULL,
              nota1 INT,
              nota2 INT
              );";

    $result = mysqli_query($conn, $consulta);

    $consulta = "INSERT INTO Aluno VALUES (1, 'Luana Amorim', 'luanaamorim', 'luana@gmail.com', '12345');";
    $result = mysqli_query($conn, $consulta);
    $consulta = "INSERT INTO Aluno VALUES (2, 'Gustavo Policarpo', 'gustavopolicarpo', 'policarpo@gmail.com', '12345');";
    $result = mysqli_query($conn, $consulta);
    $consulta = "INSERT INTO Aluno VALUES (3, 'Carlos Gusmao', 'carlosgusmao', 'carlos@gmail.com', '1234');";
    $result = mysqli_query($conn, $consulta);

    $materias = array("MAT", "BIO", "FDI", "ACED", "QUIM", "FIS", "HIST", "PORT", "ING", "FILO", "SOCIO", "BD");

    $stmt = $conn->prepare("INSERT INTO Materia VALUES (1, ?, 79, 90)");
    $stmt->bind_param('s', $mat);
    for ($i = 0; $i < count($materias); $i++)
    {
      $mat = $materias[$i];
      $stmt->execute();
    }

    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO Materia VALUES (2, ?, 58, 100)");
    $stmt->bind_param('s', $mat);
    for ($i = 0; $i < count($materias); $i++)
    {
      $mat = $materias[$i];
      $stmt->execute();
    }

    $stmt->close();
?>





