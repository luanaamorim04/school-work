<?php
    session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <title>Principal-Aluno</title>
		<link rel="stylesheet" href="estilo.css">
		<script type="text/javascript" src="./script.js"></script>  
	</head>
	<body>
		<header class="menu">
            <a href="./index.php"> 
                <div class="esq_menu">
                    <div>
                        <img src="./imagens/logo.png" class="cartola">
                    </div>
                    
                </div>
                <div class="esq_menu">
                    <p style="margin-top: 20px;font-size: 30px;">Portal do aluno</p>
                </div>
            </a>
            <a href="./login.php">
                <div class="dir_menu">
                    <img src="./imagens/logout.png" class="icone_menu" id="logout">
                </div>
            </a>
            
            <a href="./settings.php">
                <div class="dir_menu">
                    <img src="./imagens/settings.png" class="icone_menu">
                </div>
            </a>
        </header>

		<section>
			<table class="caixa">
				<tr>
					<td class="icone" onclick="a1()">
						<a href="./notas.php">
							<img class="imgIcon" src="./imagens/book.png">
							<h3>Notas</h3>
						</a>
					</td>
					<td class="icone" onclick="a2()">
						<a href="./horario.php">
							<img class="imgIcon" src="./imagens/clock.png">
							<h3>Horário</h3>
						</a>
					</td>
					<td class="aviso" rowspan=2>
						<h2 style="margin-top: -180px; margin-left: 30px">Avisos</h2>
						<div style="width: 500px; height: 280px; margin-left: 30px; margin-bottom: -190px">
							<div class="linha">
								<h3 class="texto">FDI: nota do segundo trimestre lançada</h3>
							</div>
							<div class="linha">
								<h3 class="texto">ACED: nota do terceiro trimestre lançada</h3>
							</div>
							<div class="linha">
								<h3 class="texto">BIO: nota do segundo trimestre atualizada</h3>
							</div>
							<div class="linha">
								<h3 class="texto">feriado dia 20 de janeiro</h3>
							</div>
						</div>
					</td>
				</tr>
				<tr>
					<td class="icone" onclick="a3()">
						<a href="./calendario.php">
							<img class="imgIcon" src="./imagens/calendar.png">
							<h3>Calendario</h3>
						</a>
					</td>
					<td class="icone" onclick="a4()">
						<a href="./matricula.php">
							<img class="imgIcon" src="./imagens/clipboard.png">
							<h3>Matricula</h3>
						</a>
					</td>	
				</tr>
			</table>
		</section>

		<footer>
            <div>
                <p class="embaixo">Av. Maracanã, 229 - Maracanã, Rio de Janeiro - RJ, 20271-110. Copyright J+L</p>
            </div>
        </footer>
	</body>
</html>