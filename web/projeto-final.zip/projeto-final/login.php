<?php
    $error = "";
    $conn = mysqli_connect('localhost', 'root', '');
    mysqli_select_db($conn, 'dados');
    session_start();
    if($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        $myusername = $_POST['username'];
        $mypassword = $_POST['password']; 
        $qry = "SELECT * FROM Aluno WHERE login='$myusername' AND senha='$mypassword';";
        $resp = mysqli_query($conn, $qry);
        $qnt = mysqli_num_rows($resp);
        if (!$qnt)
        {
            $error = 'login ou senha inválidos';
        }
        else
        {
            $row = mysqli_fetch_assoc($resp);

            $_SESSION['matricula'] = $row['matricula'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['nome'] = $row['nome'];
            $_SESSION['login'] = $row['login'];
            $_SESSION['senha'] = $row['senha'];
            $mat = $row['matricula'];
            $q = "SELECT * FROM Materia WHERE matricula='$mat'";
            $resp = $conn->query($q);
            $qnt = mysqli_num_rows($resp);
            for ($i = 0; $i < $qnt; $i++)
            {
                $row = mysqli_fetch_assoc($resp);
                $nome = $row['nome'];
                $nota1 = $row['nota1'];
                $nota2 = $row['nota2'];
                $idx = $nome . '1';
                $_SESSION[$idx] = $nota1;
                $idx = $nome . '2';
                $_SESSION[$idx] = $nota2;
            }

            header("location: ./index.php");
            exit();
        }
   }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="./estilo.css">
        <script type="text/javascript" src="./script.js"></script> 
    </head>
    <body>
        <header class="menu">
            <a href="./login.php"> 
                <div class="esq_menu">
                    <div>
                        <img src="./imagens/logo.png" class="cartola">
                    </div> 
                </div>
                <div class="esq_menu">
                    <p style="margin-top: 20px;font-size: 30px;">Portal do aluno</p>
                </div>
            </a>
        </header>

        <section>
            <form class="caixa" style="width: 50%" action="" method="post">
                <div>
                   <div class="linhaC" style="margin-top: 10%">
                        <?php echo $error?>
                    </div>  
                   <div class="linhaC" style="margin-top: 10%">
                        <label for="nome" style="font-size: 30px">login:</label>
                        <input style="font-size: 30px" type="text" name="username">
                    </div> 
                    <div class="linhaC" style="margin-top: 50px">
                        <label style="font-size: 30px">senha:</label>
                        <input style="font-size: 30px" type="text" name="password">
                    </div> 
                    <div class="linhaC">
                        <input type="submit" value="Confirmar" style="margin-top: 30px" class="botao"></input>
                    </div>
                </div>
            </form>
        </section>

        <footer>
            <div>
                <p class="embaixo">Av. Maracanã, 229 - Maracanã, Rio de Janeiro - RJ, 20271-110. Copyright J+L</p>
            </div>
        </footer>
    </body>
</html>