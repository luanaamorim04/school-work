<?php
    session_start();
    $error = "";
    $conn = mysqli_connect('localhost', 'root', '');
    mysqli_select_db($conn, 'dados');

    if($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        if (isset($_POST['nome1']))
        {
            $nome1 = $_POST['nome1'];
            $nome2 = $_POST['nome2'];
            if (strcmp($nome1, $nome2) === 0)
            {   
                $mat = $_SESSION['matricula'];
                $qry = "UPDATE Aluno SET email='$nome1' WHERE matricula='$mat';";
                $resp = mysqli_query($conn, $qry);
                $_SESSION['email'] = $nome1;
            }
        }
        else
        {
            $senhaant = $_POST['senhaant'];
            $senha1 = $_POST['senha1'];
            $senha2 = $_POST['senha2'];
            if (strcmp($senha1, $senha2) === 0 && strcmp($senhaant, $_SESSION['senha']) == 0)
            {   
                $mat = $_SESSION['matricula'];
                $qry = "UPDATE Aluno SET senha='$senha1' WHERE matricula='$mat';";
                $resp = mysqli_query($conn, $qry);
                $_SESSION['senha'] = $senha1;
            }
            else
            {
                $error = "Certifique que sua senha está correta e que as duas senhas novas correspondem";
            }
        }
    }
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <title>Configurações</title>
		<link rel="stylesheet" href="./estilo.css">
		<script type="text/javascript" src="./script.js"></script>  
	</head>
	<body>

		<header class="menu">
            <a href="./index.php"> 
                <div class="esq_menu">
                    <div>
                        <img src="./imagens/logo.png" class="cartola">
                    </div>
                    
                </div>
                <div class="esq_menu">
                    <p style="margin-top: 20px;font-size: 30px;">Portal do aluno</p>
                </div>
            </a>
            <a href="./login.php">
                <div class="dir_menu">
                    <img src="./imagens/logout.png" class="icone_menu" id="logout">
                </div>
            </a>
            
            <a href="./settings.php">
                <div class="dir_menu">
                    <img src="./imagens/settings.png" class="icone_menu">
                </div>
            </a>
        </header>

		<section>
            <h1><?php echo $error ?></h1>
            <center>
                <table class="config">
                    <tr>
                        <td>
                            <a onclick='change(0)'>
                                <h3>Meu perfil</h3>
                            </a>
                        </td>
                        <td rowspan=4 style=" border-left: 2px solid;width: 800px; text-align: left;">
                            <div id="nomeD">
                                <div class="linhaC" style="margin-top: 0px">
                                    <label for="nome">Nome:</label>
                                    <input readonly style="width: 400px;margin-left: 14px;font-size: 20px" type="text" name="nome" value="<?php echo $_SESSION['nome'] ?>">

                                </div> 
                                <div class="linhaC">
                                    <label>Senha:</label>
                                    <input readonly style="font-size: 20px" type="password" name="nome" value="<?php echo $_SESSION['senha'] ?>">

                                </div>  
                                <div class="linhaC">
                                    <label>Email:</label>
                                    <input readonly style="font-size: 20px" type="text" name="nome" value="<?php echo $_SESSION['email'] ?>">

                                </div> 
                            </div>
                            <form id ="senhaD" action="" method="post">
                                <div class="linhaC" style="margin-top: 0px">
                                    <label for="nome">Senha antiga:</label>
                                    <input style="font-size: 20px" type="text" name="senhaant">

                                </div> 
                                <div class="linhaC">
                                    <label>Senha nova:</label>
                                    <input style="margin-left: 26px; font-size: 20px" type="text" name="senha1">

                                </div>  
                                <div class="linhaC">
                                    <label>Repetir senha nova:</label>
                                    <input style="font-size: 20px" type="text" name="senha2">
                                </div>
                                <div class="linhaC">
                                    <button type="submit" class="botao" onclick="confirmarSenha() ">Confirmar</button>
                                </div>                                
                            </form>
                            <form id="emailD" action="" method="post">
                                <div class="linhaC" style="margin-top: -60px">
                                    <label>Novo email:</label>
                                    <input id="email1" style="margin-left: 26px; font-size: 20px" type="text" name="nome1">

                                </div>  
                                <div class="linhaC">
                                    <label>Repetir novo email:</label>
                                    <input id="email2" style="font-size: 20px" type="text" name="nome2">
                                </div>
                                <div class="linhaC">
                                    <input type="submit" value="Confirmar" class="botao" onclick="confirmarEmail()"></input>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a onclick='change(1)'>
                                <h3>Mudar senha</h3>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a onclick='change(2)'>
                                <h3>Mudar email</h3>
                            </a>
                        </td>
                    </tr>
                    
                </table>
            </center>
		</section>

		<footer>
            <div>
                <p class="embaixo">Av. Maracanã, 229 - Maracanã, Rio de Janeiro - RJ, 20271-110. Copyright J+L</p>
            </div>
        </footer>
	</body>
</html>